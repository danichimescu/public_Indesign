
// app.menuActions.itemByID(278).invoke(); // deselect all
var myDocument = app.activeDocument;
app.activeDocument.groups.everyItem().ungroup();